//
//  Item.swift
//  reWORD
//
//  Created by Irina Melikhova on 29/07/2023.
//

import Foundation

class Item: Codable {
    var title: String = ""
    var done: Bool = false
}
